Desglose de tareas – SpecTool Comparator API

1. Crear la estructura base del proyecto Flask.
2. Definir la lista inicial de herramientas en memoria.
3. Implementar el endpoint GET /tools.
4. Implementar el endpoint GET /tools/<id>.
5. Implementar el endpoint POST /tools con validación básica.
6. Implementar el endpoint GET /compare.
7. Probar los endpoints con curl o Postman.
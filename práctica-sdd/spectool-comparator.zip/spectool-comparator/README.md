Este proyecto demuestra un enfoque de desarrollo basado en especificaciones (SDD),
donde los artefactos de requisitos, diseño y tareas actúan como fuente de verdad
para la implementación de la API REST.